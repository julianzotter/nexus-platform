# Reproduktion

Generator und beide pdf_sources_*.json in denselben Ordner legen. Python3.11+ mit reportlab, pypdf und DejaVuSans/DejaVuSans-Bold/DejaVuSansMono unter /usr/share/fonts/truetype/dejavu verwenden. Der Generator erzeugt output/pdf und verwendet eingebettete Fonts. Visual-QA nach Änderungen erneut durchführen. Die gelesenen Quellen sind eingefrorene Snapshots; sie behaupten keine zukünftige Aktualität.
